# N62 Telugu Voice Studio — Netlify v1.3

## New in v1.3

- **Single Generation**: Telugu text → one MP3 → preview → reliable download.
- **Bulk Generation**: up to **30 numbered prompts**.
- Numbered filename mapping: serial `1` text is saved with serial `1` filename, etc.
- Generates each bulk MP3 through separate `/api/tts` calls with a concurrency of 3 to reduce Netlify timeout/rate-limit risk.
- Per-file status and individual download buttons.
- **Download one ZIP** containing every successfully generated MP3.
- ZIP is built in the browser with no third-party ZIP dependency.
- Neerja Indic remains default; Shruti and Mohan are available.

## Bulk input example

Text:

```text
1. దయచేసి లేన్ నుండి బయటకు వెళ్లవద్దు.
2. దయచేసి సురక్షిత దూరాన్ని పాటించండి.
3. డ్రైవింగ్ చేస్తున్నప్పుడు ఫోన్ ఉపయోగించవద్దు.
```

Filenames:

```text
1. AI_ADAS_LDW.mp3
2. AI_ADAS_HMW.mp3
3. AI_DMS_Call.mp3
```

The tool matches by serial number. It does not depend on row position.

## Deploy to Netlify

Upload/commit the contents of this folder to the root of your GitHub repository and let Netlify redeploy.

`netlify.toml` already configures:

```text
Publish directory: public
Functions directory: netlify/functions
```

After deployment, health-check:

```text
https://YOUR-SITE.netlify.app/.netlify/functions/tts
```

Expected version: `1.3.0`.

## Audio

Backend: `msedge-tts 2.0.7`

Default voice: `en-IN-NeerjaIndicNeural`

Output: 24 kHz, 48 kbps, mono MP3.

Before N62 firmware deployment, compare these properties with a known-good original N62 voice file.
