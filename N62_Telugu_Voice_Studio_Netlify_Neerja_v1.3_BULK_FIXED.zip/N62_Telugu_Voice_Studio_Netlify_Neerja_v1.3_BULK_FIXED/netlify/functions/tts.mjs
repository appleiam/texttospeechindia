import { MsEdgeTTS, OUTPUT_FORMAT } from "msedge-tts";

const VOICES = {
  neerja: {
    voice: "en-IN-NeerjaIndicNeural",
    label: "Neerja Indic"
  },
  shruti: {
    voice: "te-IN-ShrutiNeural",
    label: "Shruti"
  },
  mohan: {
    voice: "te-IN-MohanNeural",
    label: "Mohan"
  },
  "en-IN-NeerjaIndicNeural": {
    voice: "en-IN-NeerjaIndicNeural",
    label: "Neerja Indic"
  },
  "te-IN-ShrutiNeural": {
    voice: "te-IN-ShrutiNeural",
    label: "Shruti"
  },
  "te-IN-MohanNeural": {
    voice: "te-IN-MohanNeural",
    label: "Mohan"
  }
};

function clamp(value, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  return Math.max(min, Math.min(max, Math.round(number)));
}

function safeFilename(value) {
  let name = String(value || "telugu_voice.mp3").trim();
  name = name.replace(/[\\/:*?"<>|\x00-\x1F]/g, "_");
  if (!name.toLowerCase().endsWith(".mp3")) name += ".mp3";
  return name.slice(0, 180);
}

function json(detail, status = 200, extra = {}) {
  return new Response(JSON.stringify({ ...extra, detail }), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store"
    }
  });
}

function streamToBuffer(stream, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let settled = false;

    const finish = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const buffer = Buffer.concat(chunks);
      if (!buffer.length) reject(new Error("No audio data was returned by the TTS service."));
      else resolve(buffer);
    };

    const fail = (error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      reject(error instanceof Error ? error : new Error(String(error)));
    };

    const timer = setTimeout(() => fail(new Error("TTS generation timed out.")), timeoutMs);

    stream.on("data", (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
    stream.on("end", finish);
    stream.on("close", finish);
    stream.on("error", fail);
  });
}

async function synthesize(text, voiceName, rate, pitch, volume) {
  const tts = new MsEdgeTTS();
  try {
    await tts.setMetadata(
      voiceName,
      OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3
    );

    const { audioStream } = await tts.toStream(text, {
      rate: `${rate >= 0 ? "+" : ""}${rate}%`,
      pitch: `${pitch >= 0 ? "+" : ""}${pitch}Hz`,
      volume: `${volume >= 0 ? "+" : ""}${volume}%`
    });

    return await streamToBuffer(audioStream, 30000);
  } finally {
    try { tts.close(); } catch {}
  }
}

export default async (request) => {
  if (request.method === "GET") {
    return json("TTS function is running.", 200, {
      ok: true,
      version: "1.3.0",
      engine: "msedge-tts",
      defaultVoice: "en-IN-NeerjaIndicNeural"
    });
  }

  if (request.method !== "POST") {
    return json("Method not allowed.", 405);
  }

  let data;
  try {
    const type = request.headers.get("content-type") || "";
    if (type.includes("multipart/form-data") || type.includes("application/x-www-form-urlencoded")) {
      const form = await request.formData();
      data = Object.fromEntries(form.entries());
    } else {
      data = await request.json();
    }
  } catch {
    return json("Invalid request body.", 400);
  }

  const text = String(data?.text || "").trim();
  if (!text) return json("Please enter Telugu text.", 400);
  if (text.length > 2500) return json("Maximum 2500 characters per request.", 400);

  const requested = VOICES[data?.voice] || VOICES.neerja;
  const filename = safeFilename(data?.filename);
  const rate = clamp(data?.rate, -40, 40);
  const pitch = clamp(data?.pitch, -30, 30);
  const volume = clamp(data?.volume, -40, 40);

  try {
    const audio = await synthesize(text, requested.voice, rate, pitch, volume);

    return new Response(audio, {
      status: 200,
      headers: {
        "content-type": "audio/mpeg",
        "content-length": String(audio.length),
        "content-disposition": `inline; filename="${filename.replace(/"/g, "")}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
        "cache-control": "no-store",
        "x-tts-voice": requested.voice,
        "x-tts-engine": "msedge-tts"
      }
    });
  } catch (error) {
    console.error("TTS generation failed:", error);
    const message = error instanceof Error ? error.message : String(error);
    return json(
      "Speech generation failed on the server. Open Netlify Function logs for the exact upstream error.",
      502,
      {
        error: message,
        voice: requested.voice,
        version: "1.3.0"
      }
    );
  }
};
